"""Тесты валидатора: целевые мутации + генеративный свип по всем полям всех узлов.
Запуск: python test_validator.py"""
import copy, json, tempfile, unittest
from pathlib import Path
import validate_graph as v

HERE = Path(__file__).parent
BASE = json.loads((HERE / "BUILD_GRAPH.json").read_text(encoding="utf-8"))
REQUIRED = ("id", "source", "version", "verified_by", "replaceable_by", "scaffold", "status",
            "falsification_or_revision_condition", "depends_on")

def run(mutate, lock=None):
    d = copy.deepcopy(BASE); mutate(d)
    tmp = Path(tempfile.mkdtemp()); p = tmp / "g.json"
    p.write_text(json.dumps(d), encoding="utf-8")
    if lock is not None:
        (tmp / "g.lock.json").write_text(json.dumps(lock), encoding="utf-8")
    return v.validate(p)[0]

def node(d, nid): return next(n for n in d["nodes"] if n["id"] == nid)
def good_lock(): return {"nodes": {n["id"]: v.node_hash(n) for n in BASE["nodes"]}}

class Targeted(unittest.TestCase):
    def test_base_ok(self): self.assertEqual(run(lambda d: None), [])
    def test_empty_string_in_verified_by(self): self.assertTrue(run(lambda d: node(d,"environment").__setitem__("verified_by", [""])))
    def test_empty_source_object(self): self.assertTrue(run(lambda d: node(d,"environment").__setitem__("source", [{}])))
    def test_source_without_uri(self): self.assertTrue(run(lambda d: node(d,"human_core").__setitem__("source", [{"type":"x"}])))
    def test_no_exit_criteria(self): self.assertTrue(run(lambda d: d["lifecycle"].pop("exit_criteria")))
    def test_duplicate_id(self): self.assertTrue(run(lambda d: d["nodes"].append(copy.deepcopy(d["nodes"][0]))))
    def test_bad_status(self): self.assertTrue(run(lambda d: node(d,"scalars").__setitem__("status", "OK")))
    def test_pass_without_evidence(self): self.assertTrue(run(lambda d: node(d,"scalars").__setitem__("status", "PASS")))
    def test_pass_on_conversation_only(self):
        def m(d):
            n = node(d,"human_core"); n["status"]="PASS"
            n["evidence"]=[{"check":"reviewed the definition","result":"definition is consistent","date":"2026-11-16","source_ref":"conversation"}]
        self.assertTrue(run(m))
    def test_unknown_dependency(self): self.assertTrue(run(lambda d: node(d,"scalars")["depends_on"]["build"].append("ghost")))
    def test_null_depends_on(self): self.assertTrue(run(lambda d: node(d,"scalars").__setitem__("depends_on", None)))
    def test_null_runtime_list(self): self.assertTrue(run(lambda d: node(d,"scalars")["depends_on"].__setitem__("runtime", None)))
    def test_build_cycle(self): self.assertTrue(run(lambda d: node(d,"environment")["depends_on"]["build"].append("human_core")))
    def test_undeclared_runtime_on_scaffold(self): self.assertTrue(run(lambda d: d.__setitem__("declared_interfaces", [])))
    def test_core_directly_on_scaffold(self): self.assertTrue(run(lambda d: node(d,"human_core")["depends_on"]["runtime"].append("teacher_sources")))
    def test_stale_interface(self): self.assertTrue(run(lambda d: d["declared_interfaces"].append({"from":"learning_interface","to":"environment","substitutable":True,"reason":"x"})))
    def test_interface_unknown_node(self): self.assertTrue(run(lambda d: d["declared_interfaces"].append({"from":"ghost","to":"teacher_sources","substitutable":True,"reason":"x"})))
    def test_interface_from_non_interface(self): self.assertTrue(run(lambda d: d["declared_interfaces"][0].__setitem__("from", "human_core")))
    def test_interface_not_substitutable(self): self.assertTrue(run(lambda d: d["declared_interfaces"][0].__setitem__("substitutable", False)))
    def test_runtime_cycle_undeclared(self): self.assertTrue(run(lambda d: node(d,"human_core")["depends_on"]["runtime"].append("operations")))
    def test_runtime_cycle_declared_ok(self):
        def m(d):
            node(d,"human_core")["depends_on"]["runtime"].append("operations")
            d["declared_runtime_cycles"] = [{"nodes":["human_core","operations"],"reason":"supervision loop"}]
        self.assertEqual(run(m), [])
    def test_evidence_not_list(self): self.assertTrue(run(lambda d: node(d,"environment").__setitem__("evidence", None)))
    def test_evidence_bad_date(self): self.assertTrue(run(lambda d: node(d,"environment")["evidence"][0].__setitem__("date", "yesterday")))
    def test_evidence_vacuous_result(self): self.assertTrue(run(lambda d: node(d,"environment")["evidence"][0].__setitem__("result", "ok")))
    def test_evidence_identical_fields(self):
        def m(d):
            e = node(d,"environment")["evidence"][0]; e["result"] = e["check"]
        self.assertTrue(run(m))
    def test_evidence_foreign_source_ref(self): self.assertTrue(run(lambda d: node(d,"environment")["evidence"][0].__setitem__("source_ref", "https://example.com")))
    def test_lock_ok(self): self.assertEqual(run(lambda d: None, lock=good_lock()), [])
    def test_lock_lost_node(self):
        lk = good_lock(); lk["nodes"]["ghost_node"] = "0"*64
        self.assertTrue(any("lost" in e for e in run(lambda d: None, lock=lk)))
    def test_lock_changed_node(self):
        self.assertTrue(any("changed" in e for e in run(lambda d: node(d,"scalars").__setitem__("version","hypothesis-0.2"), lock=good_lock())))
    def test_lock_new_node(self):
        def m(d):
            n = copy.deepcopy(node(d,"scalars")); n["id"]="extra"; d["nodes"].append(n)
        self.assertTrue(any("new" in e for e in run(m, lock=good_lock())))

    def test_future_evidence_date(self):
        """v0.4: evidence date in the future is rejected."""
        def m(d):
            node(d,"environment")["evidence"][0]["date"] = "2099-01-01"
        self.assertTrue(run(m))
    def test_duplicate_evidence(self):
        """v0.4: duplicate evidence entries are rejected."""
        def m(d):
            ev = node(d,"environment")["evidence"][0]
            node(d,"environment")["evidence"].append(dict(ev))
        self.assertTrue(run(m))
    def test_ghost_in_declared_cycle(self):
        """v0.4: declared_runtime_cycles with unknown node is rejected."""
        def m(d):
            d["declared_runtime_cycles"] = [{"nodes":["ghost","human_core"],"reason":"test"}]
        self.assertTrue(run(m))
    def test_trivial_check_phrase(self):
        """v0.4: 'checked it works' is rejected as vacuous."""
        def m(d):
            node(d,"environment")["evidence"][0]["check"] = "checked it works"
            node(d,"environment")["evidence"][0]["result"] = "result is positive and confirmed"
        self.assertTrue(run(m))

class Sweep(unittest.TestCase):
    """Полнота: каждое обязательное поле каждого узла, будучи удалённым или null, должно ломать валидатор."""
    def test_delete_or_null_every_required_field(self):
        missed = []
        for i, n in enumerate(BASE["nodes"]):
            for f in REQUIRED:
                for how in ("delete", "null"):
                    def m(d, i=i, f=f, how=how):
                        if how == "delete": d["nodes"][i].pop(f, None)
                        else: d["nodes"][i][f] = None
                    if not run(m): missed.append((n["id"], f, how))
            def m_ev(d, i=i): d["nodes"][i]["evidence"] = None
            if not run(m_ev): missed.append((n["id"], "evidence", "null"))
        self.assertEqual(missed, [])
    def test_empty_values(self):
        missed = []
        for i, n in enumerate(BASE["nodes"]):
            for f, empty in (("id",""),("version",""),("falsification_or_revision_condition","  "),
                             ("source",[]),("verified_by",[]),("replaceable_by",[])):
                def m(d, i=i, f=f, empty=empty): d["nodes"][i][f] = empty
                if not run(m): missed.append((n["id"], f))
        self.assertEqual(missed, [])

if __name__ == "__main__":
    unittest.main(verbosity=1)
