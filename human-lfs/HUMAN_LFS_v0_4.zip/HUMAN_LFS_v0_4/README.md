# HUMAN-LFS v0.3

Починка v0.2 (прислан). Экспериментальный артефакт, не доказательство концепции.

## Состав
- `BUILD_GRAPH.json` — 6 узлов, рёбра `depends_on` (build / runtime), `status`, `evidence`, `declared_interfaces`.
- `BUILD_GRAPH.lock.json` — хэш каждого узла; потеря или тихая правка узла = ошибка.
- `validate_graph.py` — валидатор структуры и правил (stdlib).
- `test_validator.py` — 32 теста: целевые мутации + свип «каждое поле каждого узла удалить / null / пусто».
- `README.md` — этот файл.

## Запуск
```bash
python validate_graph.py
python test_validator.py
python validate_graph.py --update-lock   # только после осознанной правки графа
```

## Что изменилось относительно v0.2
1. **Разделение «учителя»** (предложение коллеги). `teachers` → `teacher_sources` (конкретные источники, `scaffold=true`) + `learning_interface` (`role=INTERFACE`, `scaffold=false`). Ядро зависит от способности получать и проверять опыт, а не от конкретного учителя. Зависимость «интерфейс → источники» объявлена в `declared_interfaces` с `substitutable=true`.
   Отдельный узел «способность учиться» не заведён: способность не собирается отдельно, она проверяется тем, что интерфейс переживает потерю любого источника (`removal_test` в `verified_by`, пока не автоматизирован).
2. **Chroot-правило ужесточено.** Узел без лесов зависит в рантайме от лесов только через узел `INTERFACE` и только при объявлении.
3. **Runtime-циклы** запрещены, если не объявлены в `declared_runtime_cycles`.
4. **Evidence строже.** `source_ref` обязателен, это один из uri самого узла и не `conversation`; пустые по смыслу `check`/`result` («ok», <12 символов, одинаковые) отвергаются; дата `YYYY-MM-DD`.
5. **Lock-файл** ловит потерю узлов и неучтённые правки при пересборке.
6. **Свип-тест** закрывает вопрос «14 тестов ≠ полнота»: перебирает все обязательные поля всех узлов. Те же тесты против валидатора v0.2 дают 11 падений из 32.
7. **`environment` = PASS** для узкого утверждения: первоисточник LFS (книги 12.1 и 9.0) подтверждает, что новая система собирается из уже установленного дистрибутива-хоста, а после toolchain сборка не зависит от хоста, кроме запущенного ядра. PASS не распространяется на «мировые практики» вообще, а утверждение про «кроме ядра» проверено на 9.0, не на текущей stable.

## Чего валидатор не делает
Не проверяет, что содержимое `evidence` истинно, и не открывает ссылки. Он только не даёт записать пустое или самоссылочное доказательство. Истинность подтверждает человек или проверка по первоисточнику. Подмена `conversation` внешней ссылкой технически проходит, пока `source_ref` совпадает с uri узла.

## Наблюдение и открытый вопрос
Даже в LFS независимость от хоста неполная: остаётся запущенное ядро. Для HUMAN-LFS это значит, что `exit_criteria` «система живёт без лесов» стоит дополнить явной записью остаточной зависимости (что именно остаётся от среды). Пока не добавлено: решает владелец графа.

## v0.4 — independent audit fixes (Z.ai, 2026-11-16)

Независимый аудит v0.3: 10 мутационных атак, 5 отбито, 5 прошли.

### Исправлено
1. **Future evidence date** — `2099-01-01` принимался; теперь `date > today` = error.
2. **Duplicate evidence** — одинаковые evidence entries принимались; теперь dedup by (check, result, date, source_ref).
3. **Ghost nodes in declared_runtime_cycles** — неизвестные ID в циклах принимались; теперь проверяются against by_id.
4. **Expanded TRIVIAL** — "checked it works", "looks good", "seems fine", "works fine", "confirmed", "approved", "passed", "success" добавлены к vacuous phrases.

### Не исправлено (осознанные границы)
- **Fake source URL** — узел может иметь source с любым URL; tool не fetching URLs (semantic gap, как в lex-naturae).
- **Lock self-attestation** — если изменить и граф, и lock одновременно, validator passes. Внешний witness нужен для полного решения.

### Проверка
- 36/36 тестов PASS (32 v0.3 + 4 v0.4)
- Validator: STRUCTURE PASS, CLAIMS PASS=1 UNKNOWN=5
- environment PASS evidence верифицирован по первоисточнику LFS (WebSearch: "The LFS system will be built by using an already installed Linux distribution")
